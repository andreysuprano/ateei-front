import NavBar from "../components/NavBar";
import FormLayout from "../components/FormLayout";
import ProgressBar from "../components/ProgressBar";
import Button from "../components/Button";
import { useState } from "react";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";

export function NumeroDePontos() {
  const [pontos, setPontos] = useState("");
  const [slots, setSlots] = useState("");

  const navigate = useNavigate();

  const handleClick = () => {
    if (!pontos || !slots) {
      return toast.error("Obrigatorio inserir quantidade de pontos e Slots");
    }
    navigate("/tensoes");
  };
  return (
    <>
      <NavBar />
      <FormLayout>
        <div className="w-96">
          <p className="font-bold mb-2 text-lg">Número de pontos</p>
          <ProgressBar />
          <p className="text-sm">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia,
            mollitia dicta quibusdam natus, tempore.
          </p>
          <div className="mt-3 bg-white h-36 flex justify-center items-center">
            <img src="#" alt="imagem do produto" />
          </div>

          <p className="mt-2 font-semibold text-sm mb-1">Número de pontos</p>
          <div>
            <input
              type="number"
              name="pontos"
              onChange={(e) => setPontos(e.target.value)}
              className="w-full h-8 px-3 text-sm border-solid border-2 border-gray-300"
            />
          </div>

          <p className="mt-3 font-semibold text-sm mb-1">
            Número de Slots Reservas
          </p>
          <div>
            <input
              type="number"
              name="slots"
              onChange={(e) => setSlots(e.target.value)}
              className="w-full h-8 px-3 text-sm border-solid border-2 border-gray-300"
            />
          </div>
          <div>
            <Button
              action={handleClick}
              color="bg-primary-blue"
              text="Proximo"
            />
            <ToastContainer />
          </div>
        </div>
      </FormLayout>
    </>
  );
}
