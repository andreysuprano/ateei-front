import FormLayout from "../components/FormLayout";
import NavBar from "../components/NavBar";

export default function CheckIn() {
  return (
    <>
      <NavBar />
      <FormLayout>
        <section>
          <p className="mb-1 text-xl font-bold">
          Quantos Sinalizadores deseja adquirir?
          </p>
          <p className="text-xs mb-2">Quantidade: 1</p>
          <div className="bg-white border-solid border-2 border-slate-300 h-20 w-96 items-center grid grid-flow-col-dense ">
            <div className="w-48 px-6">
              <p className="font-semibold text-">Equipamento 1</p>
              <p className="text-xs ">Clique para personalizar</p>
            </div>
            <div className="px-16">
              <button
                type="submit"
                className="cursor-pointer rounded-md bg-blue-700 px-2 py-1 text-center text-xs font-semibold text-white w-24 h-8 mb-1">Duplicar
              </button>
              <button
                type="submit"
                className="cursor-pointer rounded-md bg-primary-blue text-xs font-semibold text-white w-24 h-8">Remover
              </button>
            </div>
          </div>
          <div className="mt-2">
            <input
              type="text"
              placeholder="Adicionar Equipamento +"
              className="w-96 h-16 bg-slate-50 text-sm text-center outline-dashed outline-2 outline-slate-300 placeholder-black"/>
          </div>

          <div className="mt-2 ">
            <input
            type="text"
            placeholder="Adicionar Monitores +"
            className="w-96 h-16 bg-slate-50 text-sm text-center outline-dashed outline-2 outline-slate-300 placeholder-black"/>
          </div>

          <button
          type="submit"
          className="cursor-pointer rounded-md bg-primary-blue px-4 py-2 text-sm font-semibold text-white w-96 mt-12">Finalizar Pedido
          </button>
        </section>
      </FormLayout>
    </>
  );
}
