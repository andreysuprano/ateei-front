
import logo from "../assets/img/logo-ateei.png"

export default function NavBar () {
  return (
  <div className="">
    <div className="flex justify-center bg-white h-30 p-5">
      <img src={logo} alt="" />
    </div>
  </div>
  )
}
